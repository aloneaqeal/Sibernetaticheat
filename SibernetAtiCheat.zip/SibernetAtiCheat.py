"""
Dead Penguin Launcher — Python / CustomTkinter
Modern Game Launcher & AI-Powered Background Anti-Cheat Monitor (Tray Enabled)
"""

import customtkinter as ctk
import threading
import subprocess
import requests
import psutil
import json
import time
import sys
import os
from datetime import datetime
from pathlib import Path

# Sistem tepsisi için gerekli yeni kütüphaneler
import pystray
from pystray import MenuItem as item
from PIL import Image, ImageDraw

# ── Ayarlar ────────────────────────────────────────────────────
CONFIG = {
    "game_name":       "Counter-Strike",
    "game_exe":        "CS_OYNA.bat",          #[cite: 1]
    "version_url":     "https://github.com/aloneaqeal/Sibernetaticheat/blob/main/version.json", #[cite: 1]
    "download_url":    "https://senin-sunucun.com/update.zip", #[cite: 1]
    "current_version": "1.2.0",
    "anticheat_log":   "anticheat.log",         #[cite: 1]
    "anticheat_exe":   "",                      #[cite: 1]
}

BLACKLIST = [
    "cheatengine", "cheatengine-x86_64", "artmoney",
    "processhacker", "x64dbg", "x32dbg", "ollydbg",
    "windbg", "dnspy", "wireshark", "fiddler",
    "hxd", "ghidra", "scylla", "injector", "cheat_engine"
]

COLORS = {
    "bg":        "#080a0f",
    "surface":   "#0f121a",
    "card":      "#141924",
    "border":    "#1f2637",
    "accent":    "#00ddff",   
    "accent2":   "#0088cc",
    "green":     "#00ff88",
    "red":       "#ff3355",
    "amber":     "#ffaa00",
    "text":      "#f0f2f5",
    "muted":     "#64748b",
}


# ══════════════════════════════════════════════════════════════
#  YAPAY ZEKA ANOMALİ ALGINI VE DEĞERLENDİRME MOTORU
# ══════════════════════════════════════════════════════════════
class AICheatEvaluator:
    def __init__(self):
        self.system_whitelisted = ["svchost", "explorer", "chrome", "discord", "spotify", "steam"]
        
    def evaluate_process(self, proc_info) -> float:
        score = 0.0
        name = proc_info.get("name", "").lower()
        
        if any(w in name for w in self.system_whitelisted):
            return 0.0  
            
        try:
            num_threads = proc_info.get("num_threads", 1)
            cpu_percent = proc_info.get("cpu_percent", 0.0)
            io_counters = proc_info.get("io_counters", None)
            
            if io_counters:
                read_write_ratio = io_counters.read_bytes / (io_counters.write_bytes + 1)
                if read_write_ratio > 500:  
                    score += 0.35
            
            if num_threads == 1 and cpu_percent > 5.0:
                score += 0.25
            elif num_threads > 150: 
                score += 0.20
                
            name_without_ext = name.split(".")[0]
            if len(name_without_ext) > 10 and sum(c.isdigit() for c in name_without_ext) > 4:
                score += 0.30  
                
        except Exception:
            return 0.0
            
        return min(score, 1.0)


# ══════════════════════════════════════════════════════════════
#  ARKA PLAN ANTİ-CHEAT MONİTÖRÜ (AI ENTEGRELİ)
# ══════════════════════════════════════════════════════════════
class AntiCheatMonitor:
    def __init__(self, on_threat=None, on_log=None):
        self.on_threat  = on_threat #[cite: 1]
        self.on_log     = on_log    #[cite: 1]
        self.running    = False     #[cite: 1]
        self._thread    = None      #[cite: 1]
        self._ac_proc   = None      #[cite: 1]
        self.ai_engine  = AICheatEvaluator() 

    def start(self):
        self.running = True #[cite: 1]
        self._thread = threading.Thread(target=self._loop, daemon=True) #[cite: 1]
        self._thread.start() #[cite: 1]

        if CONFIG["anticheat_exe"] and Path(CONFIG["anticheat_exe"]).exists(): #[cite: 1]
            try:
                self._ac_proc = subprocess.Popen( #[cite: 1]
                    [CONFIG["anticheat_exe"]], #[cite: 1]
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0 #[cite: 1]
                )
                self._log(f"Harici koruma modülü aktif edildi: {CONFIG['anticheat_exe']}")
            except Exception as e:
                self._log(f"Harici modül baslatilamadi: {str(e)}", level="ERROR")

        self._log("Dead Penguin AI Destekli Koruma Sistemi Aktif.")

    def stop(self):
        self.running = False #[cite: 1]
        if self._ac_proc: #[cite: 1]
            try:
                self._ac_proc.terminate() #[cite: 1]
            except:
                pass
            self._ac_proc = None #[cite: 1]
        self._log("Koruma sistemi durduruldu.") #[cite: 1]

    def _loop(self):
        while self.running: #[cite: 1]
            self._scan_and_analyze()
            time.sleep(2.5) #[cite: 1]

    def _scan_and_analyze(self):
        try:
            for proc in psutil.process_iter(["pid", "name", "num_threads", "cpu_percent", "io_counters"]):
                try:
                    p_info = proc.info
                    name = p_info["name"].lower().replace(".exe", "")
                    
                    if any(b in name for b in BLACKLIST): #[cite: 1]
                        msg = f"Yasakli imza algilandi: {p_info['name']} (PID: {p_info['pid']})" #[cite: 1]
                        self._log(msg, level="THREAT") #[cite: 1]
                        if self.on_threat: #[cite: 1]
                            self.on_threat("Yasakli Surec", msg) #[cite: 1]
                        continue
                        
                    threat_score = self.ai_engine.evaluate_process(p_info)
                    if threat_score >= 0.75:
                        msg = f"AI Anomali Tehdidi: {p_info['name']} (PID: {p_info['pid']}) - Risk Skoru: %{int(threat_score * 100)}"
                        self._log(msg, level="AI_THREAT")
                        if self.on_threat:
                            self.on_threat("AI Davranissal Blok", msg)
                            
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
        except Exception as e:
            self._log(f"Tarama hatasi: {str(e)}", level="ERROR")

    def _log(self, msg, level="INFO"):
        ts  = datetime.now().strftime("%H:%M:%S") #[cite: 1]
        line = f"[{ts}] [{level}] {msg}" #[cite: 1]
        try:
            with open(CONFIG["anticheat_log"], "a", encoding="utf-8") as f: #[cite: 1]
                f.write(line + "\n") #[cite: 1]
        except:
            pass
        if self.on_log: #[cite: 1]
            self.on_log(line) #[cite: 1]


# ══════════════════════════════════════════════════════════════
#  GÜNCELLEME YÖNETİCİSİ
# ══════════════════════════════════════════════════════════════
class Updater:
    def check(self): #[cite: 1]
        try:
            r = requests.get(CONFIG["version_url"], timeout=5) #[cite: 1]
            data = r.json() #[cite: 1]
            return data.get("version"), data.get("notes", "") #[cite: 1]
        except Exception:
            return None, None #[cite: 1]

    def needs_update(self, remote_version): #[cite: 1]
        if not remote_version: #[cite: 1]
            return False #[cite: 1]
        cur = tuple(int(x) for x in CONFIG["current_version"].split(".")) #[cite: 1]
        rem = tuple(int(x) for x in remote_version.split(".")) #[cite: 1]
        return rem > cur #[cite: 1]

    def download_and_apply(self, progress_cb=None): #[cite: 1]
        import zipfile, urllib.request #[cite: 1]
        tmp = Path("update_tmp.zip") #[cite: 1]
        try:
            def reporthook(count, block, total): #[cite: 1]
                if total > 0 and progress_cb: #[cite: 1]
                    pct = min(100, int(count * block * 100 / total)) #[cite: 1]
                    progress_cb(pct) #[cite: 1]

            urllib.request.urlretrieve(CONFIG["download_url"], tmp, reporthook) #[cite: 1]

            with zipfile.ZipFile(tmp, "r") as z: #[cite: 1]
                z.extractall(".") #[cite: 1]
            tmp.unlink() #[cite: 1]
            return True #[cite: 1]
        except Exception:
            if tmp.exists(): #[cite: 1]
                tmp.unlink() #[cite: 1]
            return False #[cite: 1]


# ══════════════════════════════════════════════════════════════
#  LAUNCHER UI MİMARİSİ
# ══════════════════════════════════════════════════════════════
class DeadPenguinLauncher(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{CONFIG['game_name']} — Dead Penguin Launcher")
        self.geometry("820x540")
        self.resizable(False, False)
        self.configure(fg_color=COLORS["bg"])

        ctk.set_appearance_mode("dark")

        self._monitor = AntiCheatMonitor( #[cite: 1]
            on_threat=self._on_threat, #[cite: 1]
            on_log=self._on_log, #[cite: 1]
        )
        self._updater = Updater() #[cite: 1]
        self._game_proc = None #[cite: 1]
        self._threat_count = 0 #[cite: 1]
        self._tray_icon = None

        self._build_ui()
        self._start_ac()
        self._create_tray() # Sistem tepsisi entegrasyonu
        self.after(500, self._check_update) #[cite: 1]
        
        # X butonuna basıldığında tamamen kapatmak yerine tepsiye gizle
        self.protocol("WM_DELETE_WINDOW", self._hide_to_tray)

    def _build_ui(self):
        # Sol Panel
        left = ctk.CTkFrame(self, width=220, fg_color=COLORS["surface"], corner_radius=0) #[cite: 1]
        left.pack(side="left", fill="y") #[cite: 1]
        left.pack_propagate(False) #[cite: 1]

        # Köşeli Cyberpunk Kart Yapısı
        brand_frame = ctk.CTkFrame(left, fg_color=COLORS["card"], corner_radius=4, border_width=1, border_color=COLORS["border"])
        brand_frame.pack(pady=(24, 16), padx=16, fill="x")
        
        ctk.CTkLabel(brand_frame, text="DEAD PENGUIN",
                     font=("Courier New", 18, "bold"),
                     text_color=COLORS["accent"]).pack(pady=(12, 2))
                     
        ctk.CTkLabel(brand_frame, text=f"AI CORE SYSTEM v{CONFIG['current_version']}",
                     font=("Courier New", 10, "bold"),
                     text_color=COLORS["muted"]).pack(pady=(0, 12))

        # Durum Monitörü
        status_frame = ctk.CTkFrame(left, fg_color="transparent")
        status_frame.pack(pady=10, padx=16, fill="x")

        self._status_dot = ctk.CTkLabel(status_frame, text="● KORUMA AKTIF", #[cite: 1]
                                        font=("Courier New", 12, "bold"),
                                        text_color=COLORS["green"])
        self._status_dot.pack(anchor="w")

        self._threat_label = ctk.CTkLabel(status_frame, text="Siber Tehdit: 0", #[cite: 1]
                                          font=("Courier New", 11),
                                          text_color=COLORS["muted"])
        self._threat_label.pack(anchor="w", pady=(2, 0))

        ctk.CTkFrame(left, height=1, fg_color=COLORS["border"]).pack(fill="x", padx=16, pady=16) #[cite: 1]

        # Action Butonları
        self._play_btn = ctk.CTkButton(
            left, text="▶  OYUNU BASLAT", #[cite: 1]
            font=("Courier New", 13, "bold"),
            height=45,
            corner_radius=4,
            fg_color=COLORS["accent2"], #[cite: 1]
            hover_color=COLORS["accent"], #[cite: 1]
            text_color="#000000", #[cite: 1]
            command=self._launch_game, #[cite: 1]
        )
        self._play_btn.pack(padx=16, fill="x", pady=(0, 8))

        self._update_btn = ctk.CTkButton(
            left, text="⬇ Guncelleme Denetle", #[cite: 1]
            font=("Courier New", 11, "bold"),
            height=38,
            corner_radius=4,
            fg_color=COLORS["card"], #[cite: 1]
            hover_color=COLORS["border"], #[cite: 1]
            text_color=COLORS["amber"], #[cite: 1]
            border_color=COLORS["amber"], #[cite: 1]
            border_width=1, #[cite: 1]
            command=self._do_update, #[cite: 1]
            state="disabled", #[cite: 1]
        )
        self._update_btn.pack(padx=16, fill="x")

        # İlerleme Modülü
        self._progress = ctk.CTkProgressBar(left, height=4, corner_radius=0, #[cite: 1]
                                            fg_color=COLORS["card"], #[cite: 1]
                                            progress_color=COLORS["accent"]) #[cite: 1]
        self._progress.pack(padx=16, pady=(24, 4), fill="x") #[cite: 1]
        self._progress.set(0) #[cite: 1]

        self._progress_label = ctk.CTkLabel(left, text="", #[cite: 1]
                                            font=("Courier New", 10),
                                            text_color=COLORS["muted"]) #[cite: 1]
        self._progress_label.pack()

        # Sağ Panel
        right = ctk.CTkFrame(self, fg_color=COLORS["surface"], corner_radius=0) #[cite: 1]
        right.pack(side="right", fill="both", expand=True) #[cite: 1]

        header = ctk.CTkFrame(right, fg_color=COLORS["card"], corner_radius=0, height=50) #[cite: 1]
        header.pack(fill="x") #[cite: 1]
        header.pack_propagate(False) #[cite: 1]

        ctk.CTkLabel(header, text="GÜVENLİK KONSOLU (AI ENTEGRELİ)",
                     font=("Courier New", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=16)

        self._update_status = ctk.CTkLabel(
            header, text="Sunucu baglantisi kontrol ediliyor...", #[cite: 1]
            font=("Courier New", 11),
            text_color=COLORS["muted"]) #[cite: 1]
        self._update_status.pack(side="right", padx=16) #[cite: 1]

        # Log Terminali
        self._log_box = ctk.CTkTextbox(
            right,
            font=("Courier New", 11),
            fg_color=COLORS["bg"], #[cite: 1]
            text_color=COLORS["text"], #[cite: 1]
            wrap="word", #[cite: 1]
            state="disabled", #[cite: 1]
            border_width=1, #[cite: 1]
            border_color=COLORS["border"], #[cite: 1]
            corner_radius=0, #[cite: 1]
        )
        self._log_box.pack(fill="both", expand=True, padx=16, pady=16) #[cite: 1]

        # Tehdit Bildirim Bannerı
        self._threat_banner = ctk.CTkFrame(right, fg_color="#2a0810", height=40, corner_radius=0) #[cite: 1]
        self._threat_label2 = ctk.CTkLabel(
            self._threat_banner, text="", #[cite: 1]
            font=("Courier New", 11, "bold"),
            text_color=COLORS["red"]) #[cite: 1]
        self._threat_label2.pack(expand=True) #[cite: 1]

    def _start_ac(self):
        self._monitor.start() #[cite: 1]

    def _on_log(self, line):
        self.after(0, self._append_log, line) #[cite: 1]

    def _on_threat(self, tip, detay):
        self._threat_count += 1 #[cite: 1]
        self.after(0, self._show_threat_banner, tip, detay) #[cite: 1]

    def _append_log(self, line):
        self._log_box.configure(state="normal") #[cite: 1]
        self._log_box.insert("end", line + "\n") #[cite: 1]
        self._log_box.configure(state="disabled") #[cite: 1]
        self._log_box.see("end") #[cite: 1]
        self._threat_label.configure(text=f"Siber Tehdit: {self._threat_count}") #[cite: 1]

    def _show_threat_banner(self, tip, detay):
        self._threat_label2.configure(text=f"⚠ {tip.upper()}: {detay[:65]}") #[cite: 1]
        self._threat_banner.pack(fill="x", side="bottom") #[cite: 1]
        self.after(5000, self._hide_banner) #[cite: 1]

    def _hide_banner(self):
        self._threat_banner.pack_forget() #[cite: 1]

    # ── Sistem Tepsisi (Tray Icon) Yönetimi ─────────────────────
    def _create_tray(self):
        # Dead Penguin konseptine uygun kare/köşeli geçici bir simge üret
        img = Image.new('RGB', (64, 64), color=COLORS["bg"])
        d = ImageDraw.Draw(img)
        # Ortasına siber-mavi ufak bir kare çiz (Kendi .png logon varsa Image.open ile bağlayabilirsin)
        d.rectangle([(16, 16), (48, 48)], fill=COLORS["accent"])

        menu = (
            item('Goster (Show)', self._show_from_tray, default=True),
            item('Tamamen Kapat (Exit)', self._force_quit)
        )
        self._tray_icon = pystray.Icon("dead_penguin", img, "Dead Penguin Shield", menu)
        
        # Pystray'in kendi ana döngüsü bloke etmesin diye thread içinde çalıştırıyoruz
        threading.Thread(target=self._tray_icon.run, daemon=True).start()

    def _hide_to_tray(self):
        self.withdraw() # Pencereyi görünmez yap
        self._append_log("[SİSTEM] Launcher arka plana gizlendi, AI koruma devam ediyor.")

    def _show_from_tray(self):
        self.deiconify() # Pencereyi tekrar görünür yap
        self.lift()

    def _force_quit(self):
        # Arka plandan tamamen çıkış protokolü
        if self._tray_icon:
            self._tray_icon.stop()
        self._monitor.stop()
        if self._game_proc and self._game_proc.poll() is None:
            try:
                self._game_proc.terminate()
            except:
                pass
        self.destroy()
        os._exit(0) # Tüm threadleri zorla kapat

    # ── Güncelleme ─────────────────────────────────────────────
    def _check_update(self):
        def worker():
            remote, notes = self._updater.check() #[cite: 1]
            if remote is None: #[cite: 1]
                self.after(0, self._update_status.configure,
                           {"text": "Sunucuya erisilemedi", "text_color": COLORS["red"]}) #[cite: 1]
                return
            if self._updater.needs_update(remote): #[cite: 1]
                self.after(0, self._on_update_available, remote, notes) #[cite: 1]
            else:
                self.after(0, self._update_status.configure,
                           {"text": f"Sistem Guncel ({remote})", "text_color": COLORS["green"]}) #[cite: 1]
        threading.Thread(target=worker, daemon=True).start() #[cite: 1]

    def _on_update_available(self, version, notes):
        self._update_status.configure(text=f"Yeni Sürüm: v{version}", text_color=COLORS["amber"]) #[cite: 1]
        self._update_btn.configure(state="normal") #[cite: 1]
        self._append_log(f"[SİSTEM] Yeni guncelleme algilandi: v{version} — {notes}") #[cite: 1]

    def _do_update(self):
        self._update_btn.configure(state="disabled") #[cite: 1]
        self._play_btn.configure(state="disabled") #[cite: 1]

        def worker():
            def prog(pct): #[cite: 1]
                self.after(0, self._progress.set, pct / 100) #[cite: 1]
                self.after(0, self._progress_label.configure, {"text": f"Yukleniyor... %{pct}"}) #[cite: 1]

            ok = self._updater.download_and_apply(prog) #[cite: 1]
            if ok: #[cite: 1]
                self.after(0, self._on_update_done) #[cite: 1]
            else:
                self.after(0, self._on_update_fail) #[cite: 1]

        threading.Thread(target=worker, daemon=True).start() #[cite: 1]

    def _on_update_done(self):
        self._progress.set(1) #[cite: 1]
        self._progress_label.configure(text="Guncelleme basarili ✓", text_color=COLORS["green"]) #[cite: 1]
        self._play_btn.configure(state="normal") #[cite: 1]
        self._append_log("[SİSTEM] Guncelleme paketleri basariyla entegre edildi.") #[cite: 1]

    def _on_update_fail(self):
        self._progress_label.configure(text="Indirme hatasi!", text_color=COLORS["red"]) #[cite: 1]
        self._play_btn.configure(state="normal") #[cite: 1]
        self._update_btn.configure(state="normal") #[cite: 1]

    def _launch_game(self):
        exe = Path(CONFIG["game_exe"]) #[cite: 1]
        if not exe.exists(): #[cite: 1]
            self._append_log(f"[HATA] Çalistirilabilir dosya bulunamadi: {exe.resolve()}") #[cite: 1]
            return

        self._play_btn.configure(state="disabled", text="Oyun Calisiyor...") #[cite: 1]
        self._append_log(f"[SİSTEM] Core süreç baslatiliyor: {exe}") #[cite: 1]

        def runner():
            try:
                self._game_proc = subprocess.Popen([str(exe)]) #[cite: 1]
                self._game_proc.wait() #[cite: 1]
            except Exception as e:
                self._append_log(f"[HATA] Oyun baslatilamadı: {str(e)}") #[cite: 1]
            self.after(0, self._on_game_exit) #[cite: 1]

        threading.Thread(target=runner, daemon=True).start() #[cite: 1]

    def _on_game_exit(self):
        self._play_btn.configure(state="normal", text="▶  OYUNU BASLAT") #[cite: 1]
        self._append_log("[SİSTEM] Oyun sureci sonlandirildi.") #[cite: 1]


if __name__ == "__main__":
    app = DeadPenguinLauncher()
    app.mainloop()